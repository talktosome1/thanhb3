
boolean startString = false;

void serialEvent()
{
  while(Serial.available())
  {
    char inputChar = (char)Serial.read();
    if(inputChar == '*')
    {
      startString = true;
    }
    if(startString)
    {
      inputStr += inputChar;
    }
    if((inputChar == '#')&&(startString == true)) 
    {
//      Serial.println(inputStr);
//      Serial.flush();
      startString = false; 
      
      if(inputStr.charAt(1) == 'A')
      {
        int lengthStr = inputStr.length();
        char inputChar[lengthStr];
        inputStr.toCharArray(inputChar, lengthStr);
        if(lengthStr>=20) sscanf(inputChar,"*A,%d,%d,%d,%d,%d,%d,%d,%d#", &value_1[0], &value_1[1], &value_1[2], 
        &value_1[3], &value_1[4], &value_1[5], &value_1[6], &value_1[7]); 
//        Serial.println(value_1[0]);
        if(value_1[1] == 4)
        {
          if(value_1[0] == 1) TURN_ON_DEVICE_1;
          if(value_1[0] == 0) TURN_OFF_DEVICE_1;         
        }
        enEEPROM = 1;
//        writeEEPROM(1);
        Serial.println(inputStr);
      }
    
      if(inputStr.charAt(1) == 'B')
      {
        int lengthStr = inputStr.length();
        char inputChar[lengthStr];
        inputStr.toCharArray(inputChar, lengthStr);
        if(lengthStr>=20) sscanf(inputChar,"*B,%d,%d,%d,%d,%d,%d,%d,%d#", &value_2[0], &value_2[1], &value_2[2], 
        &value_2[3], &value_2[4], &value_2[5], &value_2[6], &value_2[7]); 
//        Serial.println(value_2[0]);
        if(value_2[1] == 4)
        {
          if(value_2[0] == 1) TURN_ON_DEVICE_2;
          if(value_2[0] == 0) TURN_OFF_DEVICE_2;         
        }
        enEEPROM = 2;
//        writeEEPROM(2);
        Serial.println(inputStr);
      }
    
      if(inputStr.charAt(1) == 'C')
      {
        int lengthStr = inputStr.length();
        char inputChar[lengthStr];
        inputStr.toCharArray(inputChar, lengthStr);
        if(lengthStr>=20) sscanf(inputChar,"*C,%d,%d,%d,%d,%d,%d,%d,%d#",&value_3[0], &value_3[1], &value_3[2], 
        &value_3[3], &value_3[4], &value_3[5], &value_3[6], &value_3[7]);
        if(value_3[1] == 4)
        {
          if(value_3[0] == 1) TURN_ON_DEVICE_3;
          if(value_3[0] == 0) TURN_OFF_DEVICE_3;         
        }
        enEEPROM = 3;
//        writeEEPROM(3);
//        Serial.println(inputStr);
      }
      
      if(inputStr.charAt(1) == 'D')
      {
        int lengthStr = inputStr.length();
        char inputChar[lengthStr];
        inputStr.toCharArray(inputChar, lengthStr);
        if(lengthStr>=20) sscanf(inputChar,"*D,%d,%d,%d,%d,%d,%d,%d,%d#",&value_4[0], &value_4[1], &value_4[2], 
        &value_4[3], &value_4[4], &value_4[5], &value_4[6], &value_4[7]);
        if(value_4[1] == 4)
        {
          if(value_4[0] == 1) TURN_ON_DEVICE_4;
          if(value_4[0] == 0) TURN_OFF_DEVICE_4;         
        } 
        enEEPROM = 4;
//        writeEEPROM(4);
//        Serial.println(inputStr);
      } 
      
      if(inputStr.charAt(1)== 'T')
      {
        int lengthStr = inputStr.length();
        char inputChar[lengthStr];
        inputStr.toCharArray(inputChar, lengthStr);
        if(lengthStr>=5) sscanf(inputChar,"*T,%d,%d,%d#",&value_5[0], &value_5[1], &value_5[2]); 
        enSetTime= true;
//        Serial.println(inputStr);
      }  
      inputStr = "";
    }
  }
}

void sendString_state()
{
  for(int i=0;i<2;i++)
  {
//    Serial3.println("*S"+String(realSt_thietbi_1)+String(realSt_thietbi_2)
//    +String(realSt_thietbi_3)+String(realSt_thietbi_4)+"#");
    Serial.println("*S"+String(realSt_thietbi_1)+String(realSt_thietbi_2)
    +String(realSt_thietbi_3)+String(realSt_thietbi_4)+"#");
  }
}


void sendString_temp()
{
  for(int i=0;i<2;i++)
  {
//    Serial3.println("*T"+String(temp_c)+ "H" + String(humidity) + "#");
    Serial.println("*T"+String(temp_c)+ "H" + String(humidity) + "#");
  }
}

void sendString_vitual()
{
  for(int i=0;i<2;i++)
  {
//    Serial3.println("*O"+String(ST_controlDevice_1)+String(ST_controlDevice_2)
//    +String(ST_controlDevice_3)+String(ST_controlDevice_4)+"#");
    Serial.println("*O"+String(ST_controlDevice_1)+String(ST_controlDevice_2)
    +String(ST_controlDevice_3)+String(ST_controlDevice_4)+"#");
  }
}
