//RS > 10 SPI SS
//R/W > 11 SPI MOSI
//E > 13 SPI SCK
// PSB > GND SPI MODE
#include "Arduino.h"
#include "U8glib.h"


U8GLIB_ST7920_128X64 u8g(13, 11, 10,U8G_PIN_NONE);
void hien()
{
  u8g.firstPage();
  do
  {
    u8g.setFont(u8g_font_5x7);
    u8g.setPrintPos(1, 6); 
    u8g.print((int)value_1[0]);
  }
  while( u8g.nextPage() );
}
void hienthi() 
{
  u8g.firstPage();  
  do 
  {
    u8g.setFont(u8g_font_5x7);
    
    u8g.drawLine(62, 2, 62, 12);
    u8g.drawLine(62, 18, 62, 28);
    u8g.drawLine(62, 34, 62, 44);
    u8g.drawLine(62, 51, 62, 61);
//    u8g.drawLine(0, 31, 128, 31);
//    u8g.drawLine(0, 31, 128, 31);
//    u8g.drawLine(0, 31, 128, 31);

    //-------- Hiển thị thiết bị 1 -------//
    //-------- Hiển thị thiết bị 1 -------//
    //-------- Hiển thị thiết bị 1 -------//
    u8g.setPrintPos(1, 6); 
    u8g.print("Device1:"); 
    if(value_1[0] == 1)  u8g.print("ON");
    if(value_1[0] == 0)  u8g.print("OFF");
//    u8g.print(" - "); 
    u8g.setPrintPos(1, 13);   
    if(value_1[1] == 1)
    {
      u8g.print((int)value_1[3]);  u8g.print("h"); 
      u8g.print((int)value_1[4]); u8g.print("'");  u8g.print("-"); 
      u8g.print((int)value_1[5]);  u8g.print("h"); 
      u8g.print((int)value_1[6]); u8g.print("'");
    }
    if(value_1[1] == 2)
    {
      u8g.print((int)value_1[3]);  u8g.print("h"); 
      u8g.print((int)value_1[4]);  u8g.print("'"); u8g.print("-"); 
      u8g.print("null");
    }
    if(value_1[1] == 3)
    {
      u8g.print("null-");
      u8g.print((int)value_1[5]);  u8g.print("h"); 
      u8g.print((int)value_1[6]); u8g.print("'");
    }
    if(value_1[1] == 4) u8g.print("null-null");

    u8g.setPrintPos(71, 6); 
    u8g.print("Temp max:");  u8g.print(value_1[6]); 
    u8g.setPrintPos(71, 13);   
    u8g.print("Temp min:");  u8g.print(value_1[7]); 


    //-------- Hiển thị thiết bị 2 -------//
    u8g.drawLine(0, 15, 128, 15);
    u8g.setPrintPos(1, 23); 
    u8g.print("Device2:"); 
    if(value_2[0] == 1)  u8g.print("ON");
    if(value_2[0] == 0)  u8g.print("OFF");
//    u8g.print(" - "); 
    u8g.setPrintPos(1, 30); 
    if(value_2[1] == 1)
    {
      u8g.print((int)value_2[2]);  u8g.print("h"); 
      u8g.print((int)value_2[3]); u8g.print("'");  u8g.print("-"); 
      u8g.print((int)value_2[4]);  u8g.print("h"); 
      u8g.print((int)value_2[5]); u8g.print("'");
    }
    if(value_2[1] == 2)
    {
      u8g.print((int)value_2[2]);  u8g.print("h"); 
      u8g.print((int)value_2[3]);  u8g.print("'"); u8g.print("-"); 
      u8g.print("null");
    }
    if(value_2[1] == 3)
    {
      u8g.print("null-");
      u8g.print((int)value_2[4]);  u8g.print("h"); 
      u8g.print((int)value_2[5]); u8g.print("'");
    }
    if(value_2[1] == 4)
    {
      u8g.print("null-null");
    }
    
   u8g.setPrintPos(71, 23);  
    u8g.print("Temp max:");  u8g.print(value_2[6]); 
    u8g.setPrintPos(71, 30);   
    u8g.print("Temp min:");  u8g.print(value_2[7]); 


    //-------- Hiển thị thiết bị 3 -------//
    u8g.drawLine(0, 31, 128, 31);
    u8g.setPrintPos(1, 39); 
    u8g.print("Device3:"); 
    if(value_3[0] == 1)  u8g.print("ON");
    if(value_3[0] == 0)  u8g.print("OFF");
//    u8g.print(" - "); 
    u8g.setPrintPos(1, 46); 
    if(value_3[1] == 1)
    {
      u8g.print((int)value_3[2]);  u8g.print("h"); 
      u8g.print((int)value_3[3]); u8g.print("'");  u8g.print("-"); 
      u8g.print((int)value_3[4]);  u8g.print("h"); 
      u8g.print((int)value_3[5]); u8g.print("'");
    }
    if(value_3[1] == 2)
    {
      u8g.print((int)value_3[2]);  u8g.print("h"); 
      u8g.print((int)value_3[3]);  u8g.print("'"); u8g.print("-"); 
      u8g.print("null");
    }
    if(value_3[1] == 3)
    {
      u8g.print("null-");
      u8g.print((int)value_3[4]);  u8g.print("h"); 
      u8g.print((int)value_3[5]); u8g.print("'");
    }
    if(value_3[1] == 4)
    {
      u8g.print("null-null");
    }

    u8g.setPrintPos(71, 39);  
    u8g.print("Temp max:");  u8g.print(value_3[6]); 
    u8g.setPrintPos(71,46);   
    u8g.print("Temp min:");  u8g.print(value_3[7]); 
    
    //-------- Hiển thị thiết bị 4 -------//
    u8g.drawLine(0, 48, 128, 48);
    u8g.setPrintPos(1,56); 
    u8g.print("Device4:"); 
    if(value_4[0] == 1)  u8g.print("ON");
    if(value_4[0] == 0)  u8g.print("OFF");
//    u8g.print(" - ");
    u8g.setPrintPos(1, 63);  
    if(value_4[1] == 1)
    {
      u8g.print((int)value_4[2]);  u8g.print("h"); 
      u8g.print((int)value_4[3]); u8g.print("'");  u8g.print("-"); 
      u8g.print((int)value_4[4]);  u8g.print("h"); 
      u8g.print((int)value_4[5]); u8g.print("'");
    }
    if(value_4[1] == 2)
    {
      u8g.print((int)value_4[2]);  u8g.print("h"); 
      u8g.print((int)value_4[3]);  u8g.print("'"); u8g.print("-"); 
      u8g.print("null");
    }
    if(value_4[1] == 3)
    {
      u8g.print("null-");
      u8g.print((int)value_4[4]);  u8g.print("h"); 
      u8g.print((int)value_4[5]); u8g.print("'");
    }
    if(value_4[1] == 4)
    {
      u8g.print("null-null");
    }
    u8g.setPrintPos(71, 56);
    u8g.print("Temp max:");  u8g.print(value_4[6]); 
    u8g.setPrintPos(71, 63);   
    u8g.print("Temp min:");  u8g.print(value_4[7]); 
  }
  while( u8g.nextPage() );
}
