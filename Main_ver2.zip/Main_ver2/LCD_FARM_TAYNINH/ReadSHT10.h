
#define dataPin  10
#define clockPin 11
SHT1x sht1x(dataPin, clockPin);

void readSHT10()
{
  
  temp_c = sht1x.readTemperatureC() - 3;
//  temp_c = random(100);
//  temp_f = sht1x.readTemperatureF();
  humidity = sht1x.readHumidity();

  // Print the values to the serial port
//  Serial.print("Temperature: ");
//  Serial.print(temp_c); Serial.print("-----");
//  Serial.println("C / ");
//  Serial.print(temp_f, DEC);
//  Serial.print("F. Humidity: ");
//  Serial.println(humidity);
//  Serial.println("%");
  
}
