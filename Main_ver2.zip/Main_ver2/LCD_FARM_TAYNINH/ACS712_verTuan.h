
int mVperAmp = 100; // use 100 for 20A Module and 66 for 30A Module

double Voltage = 0;
//double VRMS = 0;
//double AmpsRMS = 0;
//boolean ST1=1,ST2=1, ST3=1,ST4=1;

float getVPP( int pin)
{
  float result;
  
  int readValue;             //value read from the sensor
  int maxValue = 0;          // store max value here
  int minValue = 1024;          // store min value here
  int sensorpinx;
  
switch(pin)
{
    case 1:
    sensorpinx = A0;
    break;
    case 2:
    sensorpinx = A1;
    break;
    case 3:
    sensorpinx = A2;
    break;
    case 4:
    sensorpinx = A3;
    break;
}
  
   uint32_t start_time = millis();
   while((millis()-start_time) < 10)
   {
       readValue = analogRead(sensorpinx);
       // see if you have a new maxValue
       if (readValue > maxValue) 
       {
           /*record the maximum sensor value*/
           maxValue = readValue;
       }
       if (readValue < minValue) 
       {
           /*record the maximum sensor value*/
           minValue = readValue;
       }
   }
   // Subtract min from max
   result =((maxValue - minValue) * 5.0)/1024.0; 
   return result;
 }

 
byte Status_load (float Volt, byte pin)
{
Voltage =0;
byte ST=0; 
for(int i=0;i<5;i++){
  
 Voltage += getVPP(pin);
 }
 Voltage = Voltage/5;
// Serial.print(Voltage);
// Serial.print(" Vol ");
// VRMS = (Voltage/2.0) *0.707; 
// AmpsRMS = (VRMS * 1000)/mVperAmp;
// Serial.print(AmpsRMS);
// Serial.print("AmpsRMS ");
 
 if(Voltage >=0.017)
 ST = 1;
 else
 ST=0;

 return ST;
}
