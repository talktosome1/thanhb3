void checkTime()
{
  if(value_1[1] == 4) 
  {
      enDevice_1 = 0;
  }
  if(value_2[1] == 4) 
  {
      enDevice_2 = 0;
  }
  if(value_3[1] == 4) 
  {
      enDevice_3 = 0;
  }
  if(value_4[1] == 4) 
  {
      enDevice_4 = 0;
  }
  
  int sumTime = hour*60+minute;
  int sumSetStartTime_1 = value_1[2]*60+ value_1[3];
  int sumSetStopTime_1 = value_1[4]*60+ value_1[5];
  
  int sumSetStartTime_2 = value_2[2]*60+ value_2[3];
  int sumSetStopTime_2 = value_2[4]*60+ value_2[5];
  
  int sumSetStartTime_3 = value_3[2]*60+ value_3[3];
  int sumSetStopTime_3 = value_3[4]*60+ value_3[5];
  
  int sumSetStartTime_4 = value_4[2]*60+ value_4[3];
  int sumSetStopTime_4 = value_4[4]*60+ value_4[5];
  
  if((value_1[1] == 1) || (value_1[1] == 2))
  {
    if(sumTime >= sumSetStartTime_1)
    {
        enDevice_1 = 1;
    }    
  }
  if((value_1[1] == 1) || (value_1[1] == 3))
  {
    if(sumTime >= sumSetStopTime_1)
    {      
        enDevice_1 = 0;
    }    
  }
  
///////////////////////////////////////////////
  if((value_2[1] == 1) || (value_2[1] == 2))
  {
    if(sumTime >= sumSetStartTime_2)
    {     
        enDevice_2 = 1;
    }    
  }
  if((value_2[1] == 1) || (value_2[1] == 3))
  {
    if(sumTime >= sumSetStopTime_2)
    {
        enDevice_2 = 0;
    }    
  }
  
//////////////////////////////////////////////////////////
  if((value_3[1] == 1) || (value_3[1] == 2))
  {
    if(sumTime >= sumSetStartTime_3)
    {
        enDevice_3 = 1;
    }    
  }
  if((value_3[1] == 1) || (value_3[1] == 3))
  {
    if(sumTime >= sumSetStopTime_3)
    {
        enDevice_3 = 0;
    }    
  }
////////////////////////////////////////////////////////////////////////////
  if((value_4[1] == 1) || (value_4[1] == 2))
  {
    if(sumTime >= sumSetStartTime_4)
    {
        enDevice_4 = 1;
    }    
  }
  if((value_4[1] == 1) || (value_4[1] == 3))
  {
    if(sumTime >= sumSetStopTime_4)
    {
        enDevice_4 = 0;
    }    
  }
}

void temp_device()
{
  if(enDevice_1 == 1)
  {
//    Serial.println(" pos 1");
    if(temp_c >= value_1[6])
    {
      ST_controlDevice_1 = true;  
    }
    if(temp_c <= value_1[7])
    {
      ST_controlDevice_1 = false;
    }
  }
  else
  {
    ST_controlDevice_1 = value_1[0];
  }

  if(enDevice_2 == 1)
  {
//    Serial.println(" pos 2");
    if(temp_c >= value_2[6])
    {
      ST_controlDevice_2 = true;
    }
    if(temp_c <= value_2[7])
    {
      ST_controlDevice_2 = false;
    }
  }
  else
  {
    ST_controlDevice_2 = value_2[0];
  }

  if(enDevice_3 == 1)
  {
//    Serial.println(" pos 3");
    if(temp_c >= value_3[6])
    {
      ST_controlDevice_3 = true;
    }
    if(temp_c <= value_3[7])
    {
      ST_controlDevice_3 = false;
    }
  }
  else
  {
    ST_controlDevice_3 = value_3[0];
  }

  if(enDevice_4 == 1)
  {
//    Serial.println(" pos 4");
    if(temp_c >= value_4[6])
    {
      ST_controlDevice_4 = true;
    }
    if(temp_c <= value_4[7])
    {
      ST_controlDevice_4 = false;
    }
  }
  else
  {
    ST_controlDevice_4 = value_4[0];
  }
}
