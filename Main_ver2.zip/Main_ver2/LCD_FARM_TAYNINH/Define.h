#define DEVICE_1 digitalRead(6)
#define DEVICE_2 digitalRead(7)
#define DEVICE_3 digitalRead(8)
#define DEVICE_4 digitalRead(9)

#define TURN_ON_DEVICE_1  digitalWrite(6, LOW)
#define TURN_OFF_DEVICE_1  digitalWrite(6,  HIGH)

#define TURN_ON_DEVICE_2  digitalWrite(7, LOW)
#define TURN_OFF_DEVICE_2  digitalWrite(7,  HIGH)

#define TURN_ON_DEVICE_3  digitalWrite(8, LOW)
#define TURN_OFF_DEVICE_3  digitalWrite(8,  HIGH)

#define TURN_ON_DEVICE_4  digitalWrite(9, LOW)
#define TURN_OFF_DEVICE_4  digitalWrite(9,  HIGH)

#define BUTTON_1  digitalRead(2)
#define BUTTON_2  digitalRead(3)
#define BUTTON_3  digitalRead(4)
#define BUTTON_4  digitalRead(5)

boolean ST_StartTime, ST_StopTime;
boolean ST_controlDevice_1 = false, ST_controlDevice_2 = false, ST_controlDevice_3 = false, ST_controlDevice_4 = false;

int ST_thietbi;
int realSt_thietbi_1, realSt_thietbi_2, realSt_thietbi_3, realSt_thietbi_4, ST_vitual_1, ST_vitual_2, ST_vitual_3, ST_vitual_4;
int setupTemp_max, setupTemp_min, humidity_max, humidity_min;
int setHours, setMinutes, setSeconds;
int logicTime = 4;

int setupMinute_start, setupMinute_stop;
int setupHour_start, setupHour_stop;
int count_timer_1, count_timer_2, count_timer_3;

unsigned int temp_c;
int temp_f;
int humidity;

byte address;
byte enEEPROM = 0;

boolean enDevice_1 = false, enDevice_2 = false, enDevice_3 = false, enDevice_4 = false;
boolean ST_button_1 = false, ST_button_2 = false, ST_button_3 = false, ST_button_4 = false;
boolean enReadSHT10 = false, enReadDS1307 = false, enSetTime = false, enreadStateDevice = false;
boolean enUpdateTime = true;


String inputStr = "";

int value_1[] = {ST_thietbi, logicTime, setupHour_start, setupMinute_start, setupHour_stop, setupMinute_stop, setupTemp_max, setupTemp_min};
int value_2[] = {ST_thietbi, logicTime, setupHour_start, setupMinute_start, setupHour_stop, setupMinute_stop, setupTemp_max, setupTemp_min};
int value_3[] = {ST_thietbi, logicTime, setupHour_start, setupMinute_start, setupHour_stop, setupMinute_stop, setupTemp_max, setupTemp_min};
int value_4[] = {ST_thietbi, logicTime, setupHour_start, setupMinute_start, setupHour_stop, setupMinute_stop, setupTemp_max, setupTemp_min};

int value_5[] = {realSt_thietbi_1, realSt_thietbi_2, realSt_thietbi_3, realSt_thietbi_4, ST_vitual_1, ST_vitual_2, ST_vitual_3, ST_vitual_4};
int value_6[] = {setHours, setMinutes, setSeconds};
