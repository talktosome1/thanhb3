void readStateDevice()
{
  if(DEVICE_1 == LOW)
  {
    realSt_thietbi_1 = Status_load(getVPP(1),1);
  }
  else  
  {
    realSt_thietbi_1 = 0;
  }
  if(DEVICE_2 == LOW)
  {;
    realSt_thietbi_2 = Status_load(getVPP(2),2);
  }
  else
  {
    realSt_thietbi_2 = 0;
  }
  if(DEVICE_3 == LOW)
  {
    realSt_thietbi_3 = Status_load(getVPP(3),3);
  }
  else
  {
    realSt_thietbi_3 = 0;
  }
  if(DEVICE_4 == LOW)
  {
    realSt_thietbi_4 = Status_load(getVPP(4),4);
  }
  else
  {
    realSt_thietbi_4 = 0;
  }
}

void controlDevice()
{
  if(ST_controlDevice_1)
  {
      TURN_ON_DEVICE_1;  
//      Serial.println("BAT THIET BI 1");
  }
  else 
  {
      TURN_OFF_DEVICE_1;  
//      Serial.println("DA TAT THIET BI 1");
  }

  if(ST_controlDevice_2)
  {
      TURN_ON_DEVICE_2;  
//      Serial.println("BAT THIET BI 2");
  }
  else 
  {
      TURN_OFF_DEVICE_2;  
//      Serial.println("DA TAT THIET BI 2");
  }

  if(ST_controlDevice_3)
  {
      TURN_ON_DEVICE_3;  
//      Serial.println("BAT THIET BI 3");
  }
  else 
  {
      TURN_OFF_DEVICE_3;  
//      Serial.println("DA TAT THIET BI 3");
  }

  if(ST_controlDevice_4)
  {
      TURN_ON_DEVICE_4;  
//      Serial.println("BAT THIET BI 4");
  }
  else 
  {
      TURN_OFF_DEVICE_4;  
//      Serial.println("DA TAT THIET BI 4");
  }
  
}

void buttonControl()
{
//  Serial.println("chay chay chay");
  if(BUTTON_1 == LOW)
  {
    while(BUTTON_1 == LOW);
    ST_controlDevice_1 = !ST_controlDevice_1;
    value_1[0] = ST_controlDevice_1;
    controlDevice();
    sendString_vitual();
//    Serial.println("ST_controlDevice_1: ");
//    Serial.println(ST_controlDevice_1);
    delay(1000);
  }

  if(BUTTON_2 == LOW)
  {
    while(BUTTON_2 == LOW);
    ST_controlDevice_2 = !ST_controlDevice_2;
    value_2[0] = ST_controlDevice_2;
    controlDevice();
    sendString_vitual();
    delay(1000);
  }

  if(BUTTON_3 == LOW)
  {
    while(BUTTON_3 == LOW);
    ST_controlDevice_3 = !ST_controlDevice_3;
    value_3[0] = ST_controlDevice_3;
    controlDevice();
    sendString_vitual();
    delay(1000);
  }

  if(BUTTON_4 == LOW)
  {
    while(BUTTON_4 == LOW);
    ST_controlDevice_4 = !ST_controlDevice_4;
    value_4[0] = ST_controlDevice_4;
    controlDevice();
    sendString_vitual();
    delay(1000);
  }
}

void updateStateOutput()
{
  if(DEVICE_1 == LOW)
  {
    ST_vitual_1 = 1;
  }
  else  ST_vitual_1 = 0;
  
  if(DEVICE_2 == LOW)
  {
    ST_vitual_2 = 1;
  }
  else  ST_vitual_2 = 0;

  if(DEVICE_3 == LOW)
  {
    ST_vitual_3 = 1;
  }
  else  ST_vitual_3 = 0;

  if(DEVICE_4 == LOW)
  {
    ST_vitual_4 = 1;
  }
  else  ST_vitual_4 = 0;
}
