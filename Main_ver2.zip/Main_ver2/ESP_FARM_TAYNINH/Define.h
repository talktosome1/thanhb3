#define WIFI_SETTING_RESET 14

int ST_thietbi;
int realSt_thietbi;


int setupTemp_max, setupTemp_min, humidity_max, humidity_min;
int setupMinute_start = 0, setupMinute_stop = 0;
int setupHour_start = 0, setupHour_stop = 0;
int realSt_thietbi_1, realSt_thietbi_2, realSt_thietbi_3, realSt_thietbi_4, ST_vitual_1, ST_vitual_2, ST_vitual_3, ST_vitual_4;
int currentHours, currentMinutes, currentSeconds;

char tz[] = "Asia/Ho_Chi_Minh"; //timezone
       
String inputStr = "";

byte address;
String tempShow, humidityShow;
byte logicTime;

boolean enEEPROM = false;
boolean firstEEPROM =  false;
boolean enGetTime = true;

int value_2[5][5];
int value_3[5][5];
int value_4[5][5];

int ST[3];

int value_1[] = {ST_thietbi, logicTime, setupHour_start, setupMinute_start, setupHour_stop, setupMinute_stop, setupTemp_max, setupTemp_min};

int value_5[] = {realSt_thietbi_1, realSt_thietbi_2, realSt_thietbi_3, realSt_thietbi_4, ST_vitual_1, ST_vitual_2, ST_vitual_3, ST_vitual_4};

//--------------- đọc biến hẹn giờ từ Blynk----------------------//
BLYNK_WRITE(V29)
{
  TimeInputParam setupTime(param);
  boolean ST_setupStartTime = false;
  boolean ST_setupStopTime = false;
  
  if(setupTime.hasStartTime())
  {
    value_2[4][1] = setupTime.getStartHour();
    value_2[4][2] = setupTime.getStartMinute();
    ST_setupStartTime = true;
  }
  else
  {
    ST_setupStartTime = false;
  }

  if(setupTime.hasStopTime())
  {
    value_2[4][3] = setupTime.getStopHour();
    value_2[4][4] = setupTime.getStopMinute();
    ST_setupStopTime = true; 
  }
  else
  {
    ST_setupStopTime = false;
  }
  
  if((ST_setupStartTime == true) && (ST_setupStopTime == true)) value_2[4][0] = 1;
  if((ST_setupStartTime == true) && (ST_setupStopTime == false)) value_2[4][0] = 2;
  if((ST_setupStartTime == false) && (ST_setupStopTime == true)) value_2[4][0] = 3;
  if((ST_setupStartTime == false) && (ST_setupStopTime == false)) value_2[4][0] = 4;

  address = 2;
  enEEPROM = true;
  sendString_2();

}
