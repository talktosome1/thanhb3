//--------------- đọc biến V từ Blynk----------------------//

BLYNK_WRITE(V1)
{
  value_1[0] = param.asInt(); // assigning incoming value_1 from pin V1 to a variable
  address = 1;
  enEEPROM = true;
  sendString_1();
//  Serial.println("*T#");
}

//--------------- đọc biến hẹn giờ từ Blynk----------------------//
BLYNK_WRITE(V27)
{
  TimeInputParam setupTime(param);
  boolean ST_setupStartTime = false;
  boolean ST_setupStopTime = false;
  
  if(setupTime.hasStartTime())
  {
    value_1[2] = setupTime.getStartHour();
    value_1[3] = setupTime.getStartMinute();
    ST_setupStartTime = true;
  }
  else
  {
    ST_setupStartTime = false;
  }

  if(setupTime.hasStopTime())
  {
    value_1[4] = setupTime.getStopHour();
    value_1[5] = setupTime.getStopMinute();
    ST_setupStopTime = true; 
  }
  else
  {
    ST_setupStopTime = false;
  }
  
  if((ST_setupStartTime == true) && (ST_setupStopTime == true)) value_1[1] = 1;
  if((ST_setupStartTime == true) && (ST_setupStopTime == false)) value_1[1] = 2;
  if((ST_setupStartTime == false) && (ST_setupStopTime == true)) value_1[1] = 3;
  if((ST_setupStartTime == false) && (ST_setupStopTime == false)) value_1[1] = 4;

  address = 1;
  enEEPROM = true;
  sendString_1();

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//--------------- đọc biến cài đặt nhiệt độ max từ Blynk----------------------//
BLYNK_WRITE(V11)
{
//  value_1[6]_1 = param.asInt(); // assigning incoming value_1 from pin V1 to a variable
  value_1[6] = param.asInt();
  address = 1;
  enEEPROM = true;
  sendString_1();
  
}

//--------------- đọc biến cài đặt nhiệt độ min từ Blynk----------------------//
BLYNK_WRITE(V12)
{
  value_1[7] = param.asInt(); // assigning incoming value_1 from pin V1 to a variable
  address = 1;
  enEEPROM = true;
  sendString_1();
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
