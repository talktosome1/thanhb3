

void sendString_1()
{
  for(int i=0;i<2;i++)
  {
    thanh.println("*A," + String(value_1[0]) + "," +  String(value_1[1]) + "," + String(value_1[2]) 
    + "," + String(value_1[3]) + "," + String(value_1[4]) + "," + String(value_1[5]) + "," + String(value_1[6]) + "," + String(value_1[7]) + "#"); 
    delay(50);
  }
  if(enEEPROM)  writeEEPROM(address);
}

void sendString_2()
{
  for(int i=0;i<2;i++)
  {
    thanh.println("*B," + String(value_2[0]) + "," +  String(value_2[1]) + "," + String(value_2[2]) 
    + "," + String(value_2[3]) + "," + String(value_2[4]) + "," + String(value_2[5]) + "," + String(value_2[6]) + "," + String(value_2[7]) + "#"); 
    delay(50);
  }
  if(enEEPROM)  writeEEPROM(address);
}


void sendString_3()
{
  for(int i=0;i<2;i++)
  {
    thanh.println("*C," + String(value_3[0]) + "," +  String(value_3[1]) + "," + String(value_3[2]) 
    + "," + String(value_3[3]) + "," + String(value_3[4]) + "," + String(value_3[5]) + "," + String(value_3[6]) + "," + String(value_3[7]) + "#"); 
    delay(50);
  }
  if(enEEPROM)  writeEEPROM(address);
}


void sendString_4()
{
  for(int i=0;i<2;i++)
  {
    thanh.println("*D," + String(value_4[0]) + "," +  String(value_4[1]) + "," + String(value_4[2]) 
    + "," + String(value_4[3]) + "," + String(value_4[4]) + "," + String(value_4[5]) + "," + String(value_4[6]) + "," + String(value_4[7]) + "#"); 
    delay(50);
  }
  if(enEEPROM)  writeEEPROM(address);
}
