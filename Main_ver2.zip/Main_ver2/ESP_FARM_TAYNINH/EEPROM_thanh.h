
void readEEPROM()
{
  value_1[0] = EEPROM.read(1);
  value_1[1] = EEPROM.read(2);
  value_1[2] = EEPROM.read(3);
  value_1[3] = EEPROM.read(4);
  value_1[4] = EEPROM.read(5);
  value_1[5] = EEPROM.read(6);
  value_1[6] = EEPROM.read(7);
  value_1[7] = EEPROM.read(8);

  value_2[0] = EEPROM.read(9);
  value_2[1] = EEPROM.read(10);
  value_2[2] = EEPROM.read(11);
  value_2[3] = EEPROM.read(12);
  value_2[4] = EEPROM.read(13);
  value_2[5] = EEPROM.read(14);
  value_2[6] = EEPROM.read(15);
  value_2[7] = EEPROM.read(16);


  value_3[0] = EEPROM.read(17);
  value_3[1] = EEPROM.read(18);
  value_3[2] = EEPROM.read(19);
  value_3[3] = EEPROM.read(20);
  value_3[4] = EEPROM.read(21);
  value_3[5] = EEPROM.read(22);
  value_3[6] = EEPROM.read(23);
  value_3[7] = EEPROM.read(24);


  value_4[0] = EEPROM.read(25);
  value_4[1] = EEPROM.read(26);
  value_4[2] = EEPROM.read(27);
  value_4[3] = EEPROM.read(28);
  value_4[4] = EEPROM.read(29);
  value_4[5] = EEPROM.read(30);
  value_4[6] = EEPROM.read(31);
  value_4[7] = EEPROM.read(32);


  
}

void writeEEPROM(int addr)
{
  if(addr == 1)
  {
    EEPROM.write(1, value_1[0]);
    EEPROM.write(2, value_1[1]);
    EEPROM.write(3, value_1[2]);
    EEPROM.write(4, value_1[3]);
    EEPROM.write(5, value_1[4]);
    EEPROM.write(6, value_1[5]);
    EEPROM.write(7, value_1[6]);
    EEPROM.write(8, value_1[7]);
  }
  if(addr == 2)
  {
    EEPROM.write(9, value_2[0]);
    EEPROM.write(10, value_2[1]);
    EEPROM.write(11, value_2[2]);
    EEPROM.write(12, value_2[3]);
    EEPROM.write(13, value_2[4]);
    EEPROM.write(14, value_2[5]);
    EEPROM.write(15, value_2[6]);
    EEPROM.write(16, value_2[7]);
  }
  if(addr == 3)
  {
    EEPROM.write(17, value_3[0]);
    EEPROM.write(18, value_3[1]);
    EEPROM.write(19, value_3[2]);
    EEPROM.write(20, value_3[3]);
    EEPROM.write(21, value_3[4]);
    EEPROM.write(22, value_3[5]);
    EEPROM.write(23, value_3[6]);
    EEPROM.write(24, value_3[7]);
  }
  if(addr == 4)
  {
    EEPROM.write(25, value_4[0]);
    EEPROM.write(26, value_4[1]);
    EEPROM.write(27, value_4[2]);
    EEPROM.write(28, value_4[3]);
    EEPROM.write(29, value_4[4]);
    EEPROM.write(30, value_4[5]);
    EEPROM.write(31, value_4[6]);
    EEPROM.write(32, value_4[7]);
    
  }
  EEPROM.commit();
  enEEPROM = false;
}
