//--------------- đọc biến V từ Blynk----------------------//

BLYNK_WRITE(V4)
{
  value_4[0] = param.asInt(); // assigning incoming value_4 from pin V1 to a variable
  address = 4;
  enEEPROM = true;
  sendString_4();
}

//--------------- đọc biến hẹn giờ từ Blynk----------------------//
BLYNK_WRITE(V30)
{
  TimeInputParam setupTime(param);
  boolean ST_setupStartTime = false;
  boolean ST_setupStopTime = false;
  
  if(setupTime.hasStartTime())
  {
    value_4[2] = setupTime.getStartHour();
    value_4[3] = setupTime.getStartMinute();
    ST_setupStartTime = true;
  }
  else
  {
    ST_setupStartTime = false;
  }

  if(setupTime.hasStopTime())
  {
    value_4[4] = setupTime.getStopHour();
    value_4[5] = setupTime.getStopMinute();
    ST_setupStopTime = true; 
  }
  else
  {
    ST_setupStopTime = false;
  }
  
  if((ST_setupStartTime == true) && (ST_setupStopTime == true)) value_4[1] = 1;
  if((ST_setupStartTime == true) && (ST_setupStopTime == false)) value_4[1] = 2;
  if((ST_setupStartTime == false) && (ST_setupStopTime == true)) value_4[1] = 3;
  if((ST_setupStartTime == false) && (ST_setupStopTime == false)) value_4[1] = 4;

  address = 4;
  enEEPROM = true;
  sendString_4();

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//--------------- đọc biến cài đặt nhiệt độ max  từ Blynk----------------------//
BLYNK_WRITE(V17)
{
//  value_4[6]_1 = param.asInt(); // assigning incoming value_4 from pin V1 to a variable
  value_4[6] = param.asInt();
  address = 4;
  enEEPROM = true;
  sendString_4();
  
}

//--------------- đọc biến cài đặt nhiệt độ min từ Blynk----------------------//
BLYNK_WRITE(V18)
{
  value_4[7] = param.asInt(); // assigning incoming value_4 from pin V1 to a variable
  address = 4;
  enEEPROM = true;
  sendString_4();
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
