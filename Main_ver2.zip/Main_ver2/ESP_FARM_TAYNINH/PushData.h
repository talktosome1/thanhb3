void pushSetuptime_1(int startHour, int startMinute, int stopHour, int stopMinute )
{
  Serial.print("startHour: ");  Serial.println(startHour);  
  Serial.print("startMinute: ");  Serial.println(startMinute); 
  Serial.print("stopHour: ");  Serial.println(stopHour); 
  Serial.print("stopMinute: ");  Serial.println(stopMinute); 
  int startAt_1 = (startHour*60 + startMinute)*60;
  int stopAt_1 = (stopHour*60 + stopMinute)*60;

  Serial.print("startAt_1: ");  Serial.println(startAt_1);
  Serial.print("stopAt_1: ");  Serial.println(stopAt_1);

  Blynk.virtualWrite(V20, startAt_1, stopAt_1, tz);
}
//
//void myTimerEvent()
//{
//  // You can send any value_1 at any time.
//  // Please don't send more that 10 value_1s per second.;
////-------------- gửi nhiệt độ lên blynk------------//
////-------------- gửi nhiệt độ lên blynk------------//
////-------------- gửi nhiệt độ lên blynk------------//
//  Blynk.virtualWrite(V30, tempShow);
////  Serial.print("displayNumber: ");  Serial.println(displayNumber);
//  
////-------------- gửi độ ẩm lên blynk------------//
////-------------- gửi độ ẩm lên blynk------------//
////-------------- gửi độ ẩm lên blynk------------//
////  Blynk.virtualWrite(V31, random(100));
////  Serial.print("displayNumber: ");  Serial.println(displayNumber); 
////  pushSetuptime_1(random(24), random(60), random(24), random(60));
//}
