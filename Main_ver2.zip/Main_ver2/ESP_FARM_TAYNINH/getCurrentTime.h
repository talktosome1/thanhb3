

void getCurrentTime()
{
  getTime.update();
  currentHours = getTime.getHours();
  currentMinutes = getTime.getMinutes();
  currentSeconds = getTime.getSeconds();
  delay(1000);
  Serial.print("Time: ");
  Serial.print(currentHours); Serial.print(" : ");
  Serial.print(currentMinutes); Serial.print(" : ");
  Serial.println(currentSeconds);
  for(int i=0;i<2;i++)
  {
    thanh.println("*T," + String(currentHours) + "," + String(currentMinutes) + "," + String(currentSeconds) + "#");  
  }
}
