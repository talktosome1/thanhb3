//--------------- đọc biến V từ Blynk----------------------//

BLYNK_WRITE(V3)
{
  ST[1] = param.asInt(); // assigning incoming value_3 from pin V1 to a variable
  address = 2;
  enEEPROM = true;
  sendString_3();
}

//--------------- đọc biến hẹn giờ 1 từ Blynk----------------------//
BLYNK_WRITE(V33)
{
  TimeInputParam setupTime(param);
  boolean ST_setupStartTime = false;
  boolean ST_setupStopTime = false;
  
  if(setupTime.hasStartTime())
  {
    value_3[0][1] = setupTime.getStartHour();
    value_3[0][2] = setupTime.getStartMinute();
    ST_setupStartTime = true;
  }
  else
  {
    ST_setupStartTime = false;
  }

  if(setupTime.hasStopTime())
  {
    value_3[0][3] = setupTime.getStopHour();
    value_3[0][4] = setupTime.getStopMinute();
    ST_setupStopTime = true; 
  }
  else
  {
    ST_setupStopTime = false;
  }
  
  if((ST_setupStartTime == true) && (ST_setupStopTime == true)) value_3[0][0] = 1;
  if((ST_setupStartTime == true) && (ST_setupStopTime == false)) value_3[0][0] = 2;
  if((ST_setupStartTime == false) && (ST_setupStopTime == true)) value_3[0][0] = 3;
  if((ST_setupStartTime == false) && (ST_setupStopTime == false)) value_3[0][0] = 4;

  address = 0;
  enEEPROM = true;
  sendString_3();

}


//--------------- đọc biến hẹn giờ 2 từ Blynk----------------------//
BLYNK_WRITE(V34)
{
  TimeInputParam setupTime(param);
  boolean ST_setupStartTime = false;
  boolean ST_setupStopTime = false;
  
  if(setupTime.hasStartTime())
  {
    value_3[1][1] = setupTime.getStartHour();
    value_3[1][2] = setupTime.getStartMinute();
    ST_setupStartTime = true;
  }
  else
  {
    ST_setupStartTime = false;
  }

  if(setupTime.hasStopTime())
  {
    value_3[1][3] = setupTime.getStopHour();
    value_3[1][4] = setupTime.getStopMinute();
    ST_setupStopTime = true; 
  }
  else
  {
    ST_setupStopTime = false;
  }
  
  if((ST_setupStartTime == true) && (ST_setupStopTime == true)) value_3[1][0] = 1;
  if((ST_setupStartTime == true) && (ST_setupStopTime == false)) value_3[1][0] = 2;
  if((ST_setupStartTime == false) && (ST_setupStopTime == true)) value_3[1][0] = 3;
  if((ST_setupStartTime == false) && (ST_setupStopTime == false)) value_3[1][0] = 4;

  address = 1;
  enEEPROM = true;
  sendString_3();

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//--------------- đọc biến hẹn giờ 3 từ Blynk----------------------//
BLYNK_WRITE(V35)
{
  TimeInputParam setupTime(param);
  boolean ST_setupStartTime = false;
  boolean ST_setupStopTime = false;
  
  if(setupTime.hasStartTime())
  {
    value_3[2][1] = setupTime.getStartHour();
    value_3[2][2] = setupTime.getStartMinute();
    ST_setupStartTime = true;
  }
  else
  {
    ST_setupStartTime = false;
  }

  if(setupTime.hasStopTime())
  {
    value_3[2][3] = setupTime.getStopHour();
    value_3[2][4] = setupTime.getStopMinute();
    ST_setupStopTime = true; 
  }
  else
  {
    ST_setupStopTime = false;
  }
  
  if((ST_setupStartTime == true) && (ST_setupStopTime == true)) value_3[2][0] = 1;
  if((ST_setupStartTime == true) && (ST_setupStopTime == false)) value_3[2][0] = 2;
  if((ST_setupStartTime == false) && (ST_setupStopTime == true)) value_3[2][0] = 3;
  if((ST_setupStartTime == false) && (ST_setupStopTime == false)) value_3[2][0] = 4;

  address = 2;
  enEEPROM = true;
  sendString_3();

}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//--------------- đọc biến hẹn giờ 4 từ Blynk----------------------//
BLYNK_WRITE(V36)
{
  TimeInputParam setupTime(param);
  boolean ST_setupStartTime = false;
  boolean ST_setupStopTime = false;
  
  if(setupTime.hasStartTime())
  {
    value_3[3][1] = setupTime.getStartHour();
    value_3[3][2] = setupTime.getStartMinute();
    ST_setupStartTime = true;
  }
  else
  {
    ST_setupStartTime = false;
  }

  if(setupTime.hasStopTime())
  {
    value_3[3][3] = setupTime.getStopHour();
    value_3[3][4] = setupTime.getStopMinute();
    ST_setupStopTime = true; 
  }
  else
  {
    ST_setupStopTime = false;
  }
  
  if((ST_setupStartTime == true) && (ST_setupStopTime == true)) value_3[3][0] = 1;
  if((ST_setupStartTime == true) && (ST_setupStopTime == false)) value_3[3][0] = 2;
  if((ST_setupStartTime == false) && (ST_setupStopTime == true)) value_3[3][0] = 3;
  if((ST_setupStartTime == false) && (ST_setupStopTime == false)) value_3[3][0] = 4;

  address = 3;
  enEEPROM = true;
  sendString_3();

}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//--------------- đọc biến hẹn giờ 5 từ Blynk----------------------//
BLYNK_WRITE(V37)
{
  TimeInputParam setupTime(param);
  boolean ST_setupStartTime = false;
  boolean ST_setupStopTime = false;
  
  if(setupTime.hasStartTime())
  {
    value_3[4][1] = setupTime.getStartHour();
    value_3[4][2] = setupTime.getStartMinute();
    ST_setupStartTime = true;
  }
  else
  {
    ST_setupStartTime = false;
  }

  if(setupTime.hasStopTime())
  {
    value_3[4][3] = setupTime.getStopHour();
    value_3[4][4] = setupTime.getStopMinute();
    ST_setupStopTime = true; 
  }
  else
  {
    ST_setupStopTime = false;
  }
  
  if((ST_setupStartTime == true) && (ST_setupStopTime == true)) value_3[4][0] = 1;
  if((ST_setupStartTime == true) && (ST_setupStopTime == false)) value_3[4][0] = 2;
  if((ST_setupStartTime == false) && (ST_setupStopTime == true)) value_3[4][0] = 3;
  if((ST_setupStartTime == false) && (ST_setupStopTime == false)) value_3[4][0] = 4;

  address = 4;
  enEEPROM = true;
  sendString_3();

}
